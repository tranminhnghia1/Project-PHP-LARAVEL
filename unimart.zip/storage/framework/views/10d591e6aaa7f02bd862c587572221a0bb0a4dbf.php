

<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="clearfix blog-page">
        <div class="wp-inner">
            <div class="secion" id="breadcrumb-wp">
                <div class="secion-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Blog</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="main-content fl-right">
                <div class="section" id="list-blog-wp">
                    <div class="section-head clearfix">
                        <h3 class="section-title">Blog</h3>
                    </div>
                    <div class="section-detail">
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="list-item">

                                <li class="clearfix">
                                    <a href="<?php echo e(route('detail_blog',$blog->id)); ?>" title="" class="thumb fl-left">
                                        <img src="<?php echo e(asset($blog->thumnail)); ?>" alt="">
                                    </a>
                                    <div class="info fl-right">
                                        <a href="<?php echo e(route('detail_blog',$blog->id)); ?>" title="" class="title"><?php echo e($blog->name); ?></a>
                                        <span class="create-date"><?php echo e($blog->created_at); ?></span>
                                        <p class="desc"><?php echo Str::of($blog->content)->limit(150); ?></p>
                                    </div>
                                </li>



                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="section" id="paging-wp">
                    <div class="section-detail">
                        <ul class="list-item clearfix">
                            <li>
                                <?php echo e($blogs->links()); ?>

                            </li>
                        </ul>
                    </div>
                </div>

            </div>
            <div class="sidebar fl-left">
                <div class="section" id="selling-wp">
                    <?php echo $__env->make('client.components.sidebar-productTop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="section" id="banner-wp">
                    <div class="section-detail">
                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="" title="" class="thumb">
                                <img style="    margin-bottom: 18px;" src="<?php echo e(asset($item->product_thumb)); ?>" alt="">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/client/blog.blade.php ENDPATH**/ ?>