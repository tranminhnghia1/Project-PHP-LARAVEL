
<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="checkout-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Thanh toán</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="wp-inner clearfix">
            <?php if(Cart::count() > 0): ?>
                <form action="<?php echo e(route('thankyou')); ?>" method="POST" name="form-checkout">
                    <?php echo csrf_field(); ?>
                    <div class="section" id="customer-info-wp">
                        <div class="section-head">
                            <h1 class="section-title">Thông tin khách hàng</h1>
                        </div>
                        <div class="section-detail">

                            <div class="form-row clearfix">
                                <div class="form-col fl-left">
                                    <label for="fullname">Họ tên <span style="color:red;">(*)</span></label>
                                    <input type="text" name="fullname" id="fullname" value="<?php echo e(old('fullname')); ?>">
                                    <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-col fl-right">
                                    <label for="email">Email <span style="color:red;">(*)</span></label>
                                    <input type="email" name="email" id="email"value="<?php echo e(old('email')); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-row clearfix">
                                <div class="form-col fl-left">
                                    <label for="address">Địa chỉ <span style="color:red;">(*)</span></label>
                                    <input type="text" name="address" value="<?php echo e(old('address')); ?>"
                                        id="address"placeholder="Ví dụ:48 Đường man thiện">
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-col fl-right">
                                    <label for="phone">Số điện thoại <span style="color:red;">(*)</span></label>
                                    <input type="tel" name="phone_number" id="phone"
                                        value="<?php echo e(old('phone_number')); ?>">
                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-row clearfix" style="display: flex;">
                                    <div class="form-col fl-left">
                                        <label for="province">Tỉnh / Thành phố <span style="color:red;">(*)</span></label>
                                        <select name="province" class="form-control" id="province" 
                                            style="width:247.88px;height: 34px;border: 1px solid #cccccc;">
                                            <option value="" disabled selected>Chọn tỉnh / Thành phố</option>
                                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-name="<?php echo e($provin->name); ?> "
                                                    value="<?php echo e($provin->province_id); ?>"><?php echo e($provin->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <input type="hidden" name="province_name" id="province_name">
                                        <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-col fl-right">
                                        <label style="margin-left: 33px;">Chọn Quận <span
                                                style="color:red;">(*)</span></label>
                                        <select name="district" id="district"
                                            class="form-control"placeholder="Chọn Quận Huyện" 
                                            style="margin-left: 33px; width: 277.88px;height: 34px; border: 1px solid #cccccc;">
                                            <option  selected value="">Chọn quận / Huyện</option>
                                            
                                        </select>
                                        <input type="hidden" name="district_name" id="district_name">
                                        <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-col">
                                    <label>Chọn Xã Phường <span style="color:red;">(*)</span></label>
                                    <select name="ward" id="ward"
                                        class="form-control"style="height: 34px;border: 1px solid #cccccc; width: 558px;">
                                        <option  selected value="">Chọn phường / Xã</option>
                                        

                                    </select>
                                    <input type="hidden" name="ward_name" id="ward_name">
                                    <?php $__errorArgs = ['ward'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-col">
                                    <label for="notes">Ghi chú(không bắt buộc!)</label>
                                    <textarea style="width: 558px; height: 114px;" name="note"placeholder="Ghi chú đơn hàng"></textarea>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="section" id="order-review-wp">
                        <div class="section-head">
                            <h1 class="section-title">Thông tin đơn hàng</h1>
                        </div>
                        <div class="section-detail">
                            <table class="shop-table">
                                <thead>
                                    <tr>
                                        <td>Sản phẩm</td>
                                        <td style="padding-right: 56px;">Hình ảnh</td>
                                        <td>Tổng</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="cart-item">
                                            <td class="product-name"><?php echo e($row->name); ?><strong style="color: red"
                                                    class="product-quantity">x <?php echo e($row->qty); ?></strong>
                                            </td>
                                            <td>
                                                <a href="" title="" class="thumb">
                                                    <img style="width: 78px;" src="<?php echo e(asset($row->options->thumnail)); ?>"
                                                        alt="">
                                                </a>
                                            </td>
                                            <td class="product-total"> <?php echo e(number_format($row->total, 0, ',', '.')); ?>đ</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr class="order-total">
                                        <td>Tổng đơn hàng:</td>
                                        <td><strong class="total-price"><?php echo e(Cart::total()); ?>đ</strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                            <div id="payment-checkout-wp">
                                <ul id="payment_methods">
                                    <li>
                                        <input type="radio" id="payment-home" name="payment" value="home"checked>
                                        <label for="payment-home">Thanh toán tại nhà</label>
                                    </li>
                                    <li>
                                        <input type="radio" id="payment-home" name="payment" value="direct">
                                        <label for="payment-home">Thanh toán tại cửa hàng</label>
                                    </li>
                                </ul>
                            </div>
                            <div class="place-order-wp clearfix">
                                
                                <input type="submit" id="order-now" value="Đặt hàng">
                            </div>
                        </div>
                    </div>

                </form>
            <?php else: ?>
                <p>Không có sản phẩn nào trong này.vui lòng click <a href="<?php echo e(route('homePage')); ?>">vào đây</a> để
                    mua hàng tiếp!</p>
            <?php endif; ?>
        </div>
    </div>
    <style>
        .text-danger {
            color: red;
        }
    </style>
    <script src="<?php echo e(asset('client/js/jquery-3.4.1.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#province').on('change', function() {
                let province_id = $(this).val();
                // alert(province_id);
                //console.log(province_id);
                $.ajax({
                    type: 'GET',
                    url: 'get-districts/' + province_id,

                    success: function(response) {
                        var response = JSON.parse(response);
                        console.log(response);
                        // clear the district select options xóa trùng lặp huyện của các tỉnh
                        $('#district').html('');
                        // remove duplicates from the response
                        var unique_districts = [];

                        $.each(response, function(index, element) {
                            if ($.inArray(element['district_id'], unique_districts) ===
                                -1) {
                                unique_districts.push(element['district_id']);
                                $('#district').append(
                                    `<option data-name="${element['name']} " value="${element['district_id']}">${element['name']}</option>`
                                );
                            }
                        });
                        // reset the district select value to default
                        $('#district').val('');
                    }
                });
            });
            //quận, xã
            $('#district').on('change', function() {
                let district_id = $(this).val();
                // alert(province_id);

                $.ajax({
                    type: 'GET',
                    url: 'get-wards/' + district_id,

                    success: function(response) {
                        var response = JSON.parse(response);
                        console.log(response);


                       
                        // clear the district select options xóa trùng lặp huyện của các tỉnh
                        $('#ward').html('');
                        // remove duplicates from the response
                        var unique_wards = [];

                        $.each(response, function(index, element) {
                            if ($.inArray(element['ward_id'], unique_wards) ===
                                -1) {
                                unique_wards.push(element['ward_id']);
                                $('#ward').append(
                                    `<option data-name="${element['name']} " value="${element['ward_id']}">${element['name']}</option>`
                                );
                            }
                        });

                         // response.forEach(element => {
                        //     $('#ward').append(
                        //         `<option data-name="${element['name']} " value="${element['ward_id']}">${element['name']}</option>`
                        //     );
                        // });
                        // reset the district select value to default
                        $('#ward').val('');
                    }
                });
            });
        });

        ///thêm tên tỉnh quận xã vào mysql(thêm 1 input hidden) thêm thuộc tính data-name vào option
        // Sau đó, để lấy giá trị tên tỉnh từ select box, 
        // ta có thể sử dụng JavaScript để lấy giá trị data-name tương ứng 
        // với giá trị được chọn trong select box và gán giá trị đó vào một input field ẩn.
        $('#province').on('change', function() {
            var selectedOption = $(this).find(':selected');
            var provinceName = selectedOption.data('name');
            $('#province_name').val(provinceName);
        });
        $('#district').on('change', function() {
            var selectedOption = $(this).find(':selected');
            var districtName = selectedOption.data('name');
            $('#district_name').val(districtName);
        });
        $('#ward').on('change', function() {
            var selectedOption = $(this).find(':selected');
            var wardName = selectedOption.data('name');
            $('#ward_name').val(wardName);
        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/client/checkout.blade.php ENDPATH**/ ?>