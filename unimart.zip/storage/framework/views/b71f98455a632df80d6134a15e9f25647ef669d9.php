
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <?php if(session('statuss')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('statuss')); ?>

                </div>
            <?php endif; ?>
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách đơn hàng</h5>
                <div class="form-search form-inline">
                    <form action="#">
                        <input type=""name="keyword" class="form-control form-search" placeholder="Tìm theo tên khách"
                            value="<?php echo e(request()->input('keyword')); ?>">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'active'])); ?>"class="text-primary">Tất cả<span
                            class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'success'])); ?>"class="text-primary">Thành công<span
                            class="text-muted">(<?php echo e($count[1]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'waiting'])); ?>" class="text-primary">Đang vận
                        chuyển<span class="text-muted">(<?php echo e($count[2]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'pending'])); ?>" class="text-primary">Chờ xử lí<span
                            class="text-muted">(<?php echo e($count[3]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'dustin'])); ?>" class="text-primary">Hủy đơn<span
                            class="text-muted">(<?php echo e($count[4]); ?>)</span></a>
                    <a href="" class="text-primary">Doanh số<span
                            class="text-muted">(<?php echo e(number_format($total_sales, 0, ',', '.')); ?>đ)</span></a>
                    <a href="" class="text-primary">Tổng sản phẩm trong kho<span
                            class="text-muted">(<?php echo e($total_product); ?>)</span></a>
                    
                </div>
                <form action="<?php echo e(url('admin/orders/action')); ?>" method="">
                    <?php echo csrf_field(); ?>
                    <div class="form-action form-inline py-3">
                        <select class="form-control mr-1" id="" name="act">
                            <option>Chọn</option>
                            <?php $__currentLoopData = $list_act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <option value="<?php echo e($k); ?>"><?php echo e($act); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                    </div>
                    <table class="table table-striped table-checkall" style="margin-bottom:11px !important">
                        <thead>
                            <tr>
                                <th>
                                    <input type="checkbox" name="checkall">
                                </th>
                                <th scope="col">#</th>
                                <th scope="col">Mã</th>
                                <th scope="col"style="text-align: center;">Khách hàng</th>
                                <th scope="col" style="text-align: center;">Số lượng sp</th>
                                <th scope="col"style="text-align: center;">Tổng tiền</th>
                                <th scope="col"style="text-align: center;">Trạng thái</th>
                                <th scope="col"style="text-align: center;">Thời gian</th>
                                <th scope="col"style="text-align: center;">Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($orders->total() > 0): ?>
                                <?php
                                    $t = 0;
                                ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $t++;
                                    ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="list_check[]" value="<?php echo e($item->id); ?>">
                                        </td>
                                        <td><?php echo e($t); ?></td>
                                        <td><a href="<?php echo e(route('order.edit', $item->id)); ?>"><?php echo e($item->order_code); ?></a></td>
                                        <td style="text-align: center;">
                                            <?php echo e($item->fullname); ?> <br>
                                            <?php echo e($item->phone_number); ?>

                                        </td>

                                        <td style="text-align: center;"><?php echo e($item->num_order); ?></td>
                                        <td style="text-align: center;"><?php echo e($item->total_price); ?>₫</td>
                                        <td style="text-align: center;">
                                            <?php if($item->status == 'success'): ?>
                                                <span class="badge badge-success">Thành công</span>
                                            <?php elseif($item->status == 'waiting'): ?>
                                                <span class="badge badge-warning">Đang vận chuyển</span>
                                            <?php elseif($item->status == 'dustin'): ?>
                                                <span class="badge badge-danger">Hủy đơn</span>
                                            <?php elseif($item->status == 'pending'): ?>
                                                <span class="badge badge-dark">Chờ xử lý</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center;"><?php echo e($item->created_at); ?></td>
                                        <td style="text-align: center;">
                                            
                                            <a href="<?php echo e(route('order.edit', $item->id)); ?>"
                                                class="btn btn-success btn-sm rounded-0 text-white" title=""><i
                                                    style="color: #fff; font-size: 17px;font-weight: bold;"
                                                    class="fa-regular fa-eye"></i></a>
                                            <a href="<?php echo e(route('delete_order', $item->id)); ?>"
                                                class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                title="Delete"><i onclick=" return confirm('Bạn có chắc chắn xóa không?')"
                                                    class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <td class="text text-danger bg-white" colspan="7">Không có bản ghi nào!</td>
                                
                            <?php endif; ?>
                        </tbody>
                    </table>
                </form>
                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/admin/orders/list.blade.php ENDPATH**/ ?>