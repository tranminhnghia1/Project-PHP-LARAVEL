

<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <?php if(session('statuss')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('statuss')); ?>

                </div>
            <?php endif; ?>
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                Thêm slider
                <div class="function">
                    <a href="<?php echo e(url('admin/sliders/add')); ?>"class="btn btn-success">Thêm mới</a>
                </div>
            </div>

            <div class="card-body">
                <form action="" method="">
                    <?php echo csrf_field(); ?>
                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Ảnh</th>
                                <th style="text-align:left;" scope="col">Tiêu đề</th>
                                <th style="text-align:left;" scope="col">Mô tả</th>
                                <th style="text-align:left;" scope="col">Link</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Người tạo-Ngày tạo</th>
                                <th scope="col">Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $t = 0;
                            ?>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $t++;
                                ?>
                                <tr>
                                    <td scope="row"><?php echo e($t); ?></td>
                                    <td><a class="feature_img" href=""><img style="width:110px;height:60px"
                                                src="<?php echo e(asset($slider->slider_thumb)); ?>"alt=""></a>
                                    </td>
                                    <td style="text-align:left;"><a href="<?php echo e(route('slider.edit', $slider->id)); ?>"><?php echo e($slider->name); ?></a></td>
                                    <td style="text-align:left;"><a href="<?php echo e(route('slider.edit', $slider->id)); ?>"><?php echo e($slider->content_desc); ?></a>  </td>
                                    <td style="text-align:left;"><a href="<?php echo e(route('slider.edit', $slider->id)); ?>"><?php echo e($slider->link); ?></a> </td>
                                    <td style="text-align: center;">
                                        <?php if($slider->status == 'posted'): ?>
                                            <span class="badge badge-success">Phê duyệt</span>
                                        <?php elseif($slider->status == 'waiting'): ?>
                                            <span class="badge badge-warning">Chờ duyệt</span>
                                        <?php elseif($slider->status == 'dustin'): ?>
                                            <span class="badge badge-danger">Thùng rác</span>
                                        
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php echo e($slider->user->name); ?>

                                        <p><?php echo e($slider->created_at); ?></p>
                                    </td>

                                    <td>
                                        <a href="<?php echo e(route('slider.edit', $slider->id)); ?>"
                                            class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                class="fa fa-edit"></i></a>
                                        <a href="<?php echo e(route('delete_slider', $slider->id)); ?>"
                                            class="btn btn-danger btn-sm rounded-0 text-white"
                                            onclick=" return confirm('Bạn có chắc chắn xóa không?')" type="button"
                                            data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                class="fa fa-trash"></i></a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/admin/sliders/list.blade.php ENDPATH**/ ?>