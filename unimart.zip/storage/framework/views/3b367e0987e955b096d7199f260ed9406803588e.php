

<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <?php if(session('statuss')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('statuss')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-header font-weight-bold">
                        Thêm menu
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('admin/menus/store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Tên menu</label>
                                <input class="form-control" type="text" name="name" id="name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="name">Link</label>
                                <input class="form-control" type="text" name="link" id="name">
                                <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="name">Thứ tự</label>
                                <input class="form-control" type="text" name="parent_id" id="name">
                                <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Trạng thái</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status" id="exampleRadios1"
                                        value="waiting">
                                    <label class="form-check-label" for="exampleRadios1">
                                        Chờ duyệt
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status" id="exampleRadios2"
                                        value="posted" checked>
                                    <label class="form-check-label" for="exampleRadios2">
                                        Công khai
                                    </label>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Thêm mới</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh sách
                    </div>
                    <div class="card-body">
                        <form action="" method="">
                            <?php echo csrf_field(); ?>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">STT</th>
                                        <th scope="col">Tên Menu</th>
                                        <th scope="col">Link</th>
                                        <th scope="col">Trạng thái</th>
                                        <th scope="col">Thứ tự</th>
                                        <th scope="col">Người tạo-Ngày tạo</th>
                                        <th scope="col">Tác vụ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $t = 0;
                                    ?>
                                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $t++;
                                        ?>
                                        <tr>
                                            <td scope="row"><?php echo e($t); ?></td>
                                            <td><?php echo e($menu->name); ?></td>
                                            <td><?php echo e($menu->link); ?></td>
                                            <td style="text-align: center;">
                                                <?php if($menu->status == 'posted'): ?>
                                                    <span class="badge badge-success">Phê duyệt</span>
                                                <?php elseif($menu->status == 'waiting'): ?>
                                                    <span class="badge badge-warning">Chờ duyệt</span>
                                                <?php elseif($menu->status == 'dustin'): ?>
                                                    <span class="badge badge-danger">Thùng rác</span>
                                                
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($menu->parent_id); ?></td>
                                            <td><?php echo e($menu->user->name); ?>

                                                <p><?php echo e($menu->created_at); ?></p>
                                            </td>

                                            <td>
                                                <a href="<?php echo e(route('menu.edit',$menu->id)); ?>" class="btn btn-success btn-sm rounded-0 text-white"
                                                    type="button" data-toggle="tooltip" data-placement="top"
                                                    title="Edit"><i class="fa fa-edit"></i></a>
                                                <a href="<?php echo e(route('delete_menu', $menu->id)); ?>"
                                                    class="btn btn-danger btn-sm rounded-0 text-white"
                                                    onclick=" return confirm('Bạn có chắc chắn xóa không?')" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                        class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/admin/menus/list.blade.php ENDPATH**/ ?>