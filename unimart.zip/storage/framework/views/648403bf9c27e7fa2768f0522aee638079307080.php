
<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="cart-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Giỏ hàng</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="wp-inner clearfix">
            <?php if(Cart::count() > 0): ?>
                <div class="section" id="info-cart-wp">
                    <div class="section-detail table-responsive">
                        <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">

                            <table class="table">
                                <thead>
                                    <tr>
                                        <td>Mã sản phẩm</td>
                                        <td>Ảnh sản phẩm</td>
                                        <td>Tên sản phẩm</td>
                                        <td>Giá sản phẩm</td>
                                        <td>Số lượng</td>
                                        <td colspan="2">Thành tiền</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $t = 0;
                                    ?>
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $t++;
                                        ?>

                                        <tr>
                                            <td><?php echo e($t); ?></td>
                                            <td>
                                                <a href="" title="" class="thumb">
                                                    <img src="<?php echo e(asset($row->options->thumnail)); ?>" alt="">
                                                </a>
                                            </td>
                                            <td>
                                                <a href="" title=""
                                                    class="name-product"><?php echo e($row->name); ?></a>
                                            </td>
                                            <td><?php echo e(number_format($row->price, 0, ',', '.')); ?>đ</td>
                                            <td>

                                                <input class="num_order" data-id="<?php echo e($row->rowId); ?>"
                                                    name="qty[<?php echo e($row->rowId); ?>]"
                                                    data-url="<?php echo e(route('ajax_shopping_cart')); ?>" type="number"
                                                    style="border: 1px solid #ccc;border-radius: 3px;text-align: center;height: 34px;width: 35px;"
                                                    data-rowid="[<?php echo e($row->rowId); ?>]" value="<?php echo e($row->qty); ?>"
                                                    max="10" min="1" id="num_order">
                                            </td>
                                            <td id="sub_total-<?php echo e($row->rowId); ?>">
                                                <?php echo e(number_format($row->total, 0, ',', '.')); ?>đ </td>
                                            <td>
                                                <a href="<?php echo e(route('cart.remove', $row->rowId)); ?>" title=""
                                                    class="del-product"><i class="fa fa-trash-o"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="1">Tổng số lượng sản phẩm: <span
                                                style="color: red;font-weight:bold; font-size:17px"><?php echo e(Cart::count()); ?></span>
                                        </td>
                                        <td colspan="6">
                                            <div class="clearfix">
                                                <p id="total-price" class="fl-right">Tổng giá:
                                                    <span><?php echo e(Cart::total()); ?>đ</span>
                                                </p>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="7">
                                            <div class="clearfix">
                                                <div class="fl-right">
                                                    <input id="update-cart" type="submit"value="Cập nhật giỏ hàng"
                                                        class="btn btn-secondary">
                                                    
                                                    <a href="<?php echo e(route('checkout')); ?>" title="" id="checkout-cart">Thanh
                                                        toán</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>

                        </form>
                    </div>
                </div>
                <div class="section" id="action-cart-wp">
                    <div class="section-detail">

                        <a href="<?php echo e(route('homePage')); ?>" title="" id="buy-more">Mua tiếp</a><br />
                        <a href="<?php echo e(route('cart.destroy')); ?>" title="" id="delete-cart">Xóa giỏ hàng</a>
                    </div>
                </div>
            <?php else: ?>
                <p>Không có sản phẩn nào trong giỏ hàng.click <a href="<?php echo e(route('homePage')); ?>">vào đây</a> để
                    mua hàng tiếp!</p>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/client/showCart.blade.php ENDPATH**/ ?>