
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">

            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center mb-4">
                <h5 class="m-0 ">Danh sách các quyền</h5>
                <a href="<?php echo e(route('add.permission')); ?>" class="btn btn-success">Thêm mới</a>
            </div>
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="card-body">
                <table class="table table-striped table-checkall">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th class="title" scope="col">Tên quyền</th>
                            <th scope="col">Mô tả quyền</th>
                            <th scope="col">Ngày tạo</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $t = 0;
                        ?>
                        <?php $__currentLoopData = $permissions_multip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $t++;
                            ?>
                            <tr>
                                <th scope="row"><?php echo e($t); ?></th>
                                <td class="title">
                                    <?php echo e(str_repeat('|--', $item['level']) . $item['name']); ?>

                                </td>
                                <td><?php echo e($item->permission_description); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('edit.permission',$item->id)); ?>" 
                                        class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Edit"><i
                                            class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('delete.permission',$item->id)); ?>"
                                        onclick="return confirm('Bạn có chắc chắn muốn xóa không?');"
                                        class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($permissions->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/admin/permission/list.blade.php ENDPATH**/ ?>