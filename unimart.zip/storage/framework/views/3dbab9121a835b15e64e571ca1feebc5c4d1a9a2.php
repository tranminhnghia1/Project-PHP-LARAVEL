

<?php $__env->startSection('content'); ?>
<style>
    .height-card{
        height: 72.8px; 
    }
    .cart-info{
        height: 140px;
    }
</style>
    <div class="container-fluid py-5">
        <div class="row">
            <div class="col-2">
                <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                    <div  class="card-header height-card">ĐƠN HÀNG THÀNH CÔNG</div>
                    <div class="card-body cart-info">
                        <h5 class="card-title"><?php echo e($count[0]); ?> ĐƠN</h5>
                        <p class="card-text">Đơn hàng giao dịch thành công</p>
                    </div>
                </div>
            </div>
            <div class="col-2">
                <div class="card text-white bg-info mb-3" style="max-width: 18rem;">
                    <div class="card-header height-card">ĐANG VẬN CHUYỂN</div>
                    <div class="card-body cart-info">
                        <h5 class="card-title"><?php echo e($count[1]); ?>  ĐƠN</h5>
                        <p class="card-text">Đơn hàng đang vận chuyển</p>
                    </div>
                </div>
            </div>
            <div class="col-2">
                <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
                    <div style="height: 72.8px;" class="card-header height-card">ĐANG XỬ LÝ</div>
                    <div class="card-body cart-info">
                        <h5 class="card-title"><?php echo e($count[2]); ?>  ĐƠN</h5>
                        <p class="card-text">Đơn hàng đang xử lý</p>
                    </div>
                </div>
            </div>

            <div class="col-2">
                <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                    <div  class="card-header height-card">DOANH SỐ</div>
                    <div  class="card-body cart-info" >
                        <h5 class="card-title"><?php echo e(number_format($total_sales, 0, ',', '.')); ?>Đ</h5>
                        <p class="card-text">Doanh số hệ thống</p>
                    </div>
                </div>
            </div>
            <div class="col-2">
                <div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
                    <div   class="card-header height-card">ĐƠN HÀNG HỦY</div>
                    <div class="card-body cart-info">
                        <h5 class="card-title"><?php echo e($count[3]); ?>  ĐƠN</h5>
                        <p class="card-text">Số đơn bị hủy trong hệ thống</p>
                    </div>
                </div>
            </div>
            <div class="col-2">
                <div class="card text-white bg-warning mb-3" style="max-width: 18rem;">
                    <div class="card-header height-card">TỔNG SẢN PHẨM TRONG KHO</div>
                    <div class="card-body cart-info">
                        <h5 class="card-title"><?php echo e($total_product); ?> SẢN PHẨM</h5>
                        <p class="card-text">Số lượng sản phẩm trong kho</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end analytic  -->
        <div class="card">
            <div class="card-header font-weight-bold">
                ĐƠN HÀNG MỚI
            </div>
            <div class="card-body">
                <table class="table table-striped table-checkall">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" name="checkall">
                            </th>
                            <th scope="col">#</th>
                            <th scope="col">Mã</th>
                            <th scope="col"style="text-align: center;">Khách hàng</th>
                            <th scope="col" style="text-align: center;">Số lượng sp</th>
                            <th scope="col"style="text-align: center;">Tổng tiền</th>
                            <th scope="col"style="text-align: center;">Trạng thái</th>
                            <th scope="col"style="text-align: center;">Thời gian</th>
                            <th scope="col"style="text-align: center;">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                            <?php
                                $t = 0;
                            ?>
                            <?php $__currentLoopData = $list_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $t++;
                                ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="list_check[]" value="<?php echo e($item->id); ?>">
                                    </td>
                                    <td><?php echo e($t); ?></td>
                                    <td><a href="<?php echo e(route('order.edit', $item->id)); ?>"><?php echo e($item->order_code); ?></td>
                                    <td style="text-align: center;">
                                        <?php echo e($item->fullname); ?> <br>
                                        <?php echo e($item->phone_number); ?>

                                    </td>

                                    <td style="text-align: center;"><?php echo e($item->num_order); ?></td>
                                    <td style="text-align: center;"><?php echo e($item->total_price); ?>₫</td>
                                    <td style="text-align: center;">
                                        <?php if($item->status == 'success'): ?>
                                            <span class="badge badge-success">Thành công</span>
                                        <?php elseif($item->status == 'waiting'): ?>
                                            <span class="badge badge-warning">Đang vận chuyển</span>
                                        <?php elseif($item->status == 'dustin'): ?>
                                            <span class="badge badge-danger">Hủy đơn</span>
                                        <?php elseif($item->status == 'pending'): ?>
                                            <span class="badge badge-dark">Chờ xử lý</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: center;"><?php echo e($item->created_at); ?></td>
                                    <td style="text-align: center;">
                                        
                                        <a href="<?php echo e(route('order.edit', $item->id)); ?>"
                                            class="btn btn-success btn-sm rounded-0 text-white" title=""><i
                                                style="color: #fff; font-size: 17px;font-weight: bold;"
                                                class="fa-regular fa-eye"></i></a>
                                        <a href="<?php echo e(route('delete_order',$item->id)); ?>" class="btn btn-danger btn-sm rounded-0 text-white"
                                            type="button" title="Delete"><i
                                                onclick=" return confirm('Bạn có chắc chắn xóa không?')"
                                                class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </tbody>
                </table>
                <?php echo e($list_order->links()); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>