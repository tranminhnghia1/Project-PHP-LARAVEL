

<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <p style="    font-size: 28px;
    color: red;">Bạn không có quyền truy cập vào trang này, xin vui lòng click <a style="text-transform: uppercase;font-weight: bold;"
                    href="<?php echo e(route('dashboard')); ?>">vào đây</a> để quay về Dasboard!</p>
            <img style=" display: flex;
    justify-content: center;
    align-items: center; width:500px;"
                src="<?php echo e(asset('uploads/bao-mat.jpg')); ?>" alt="">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unimart\resources\views/errors/403.blade.php ENDPATH**/ ?>