<div class="section-head">
    <h3 class="section-title">Sản phẩm bán chạy</h3>
</div>
<div class="section-detail">
    <ul class="list-item">
        <?php $__currentLoopData = $top_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="clearfix">
                <a href="<?php echo e(route('detailProduct', $product->id).$product->slug_product); ?>" title="" class="thumb fl-left">
                    <img src="<?php echo e(asset($product->product_thumb)); ?>" alt="">
                </a>
                <div class="info fl-right">
                    <a href="<?php echo e(route('detailProduct', $product->id).$product->slug_product); ?>" title="" class="product-name"><?php echo e($product->name); ?></a>
                    <div class="price">
                        <span class="new"><?php echo e(number_format($product->price_product,0,",",".")); ?>đ</span>
                        <span class="old"><?php echo e(number_format($product->price_product * 1.3,0,",",".")); ?>đ</span>
                    </div>
                    <a href="<?php echo e(route('detailProduct', $product->id).$product->slug_product); ?>" title="" class="buy-now">Xem chi tiết</a>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</div>
<?php /**PATH D:\xampp\htdocs\unimart\resources\views/client/components/sidebar-productTop.blade.php ENDPATH**/ ?>