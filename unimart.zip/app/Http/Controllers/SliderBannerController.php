<?php

namespace App\Http\Controllers;

use App\Slider;
use Illuminate\Http\Request;

class SliderBannerController extends Controller
{
    //
    // function slider(){
    //     $sliders = Slider::all();
    //     return view('client/home',compact('sliders'));
    // }
}
